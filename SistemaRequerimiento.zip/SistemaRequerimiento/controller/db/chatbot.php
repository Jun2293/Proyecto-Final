<?php
$servername = "localhost"; // Cambia si es necesario
$username = "root"; // Tu usuario de MySQL
$password = ""; // Tu contraseña de MySQL
$dbname = "reqsis";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar la solicitud del usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_message = $_POST['message'];

    // Consultar la respuesta del bot
    $stmt = $conn->prepare("SELECT bot_response FROM messages WHERE user_message = ?");
    $stmt->bind_param("s", $user_message);
    $stmt->execute();
    $stmt->bind_result($bot_response);
    $stmt->fetch();
    $stmt->close();

    // Si no se encuentra respuesta, enviar un mensaje predeterminado
    if (!$bot_response) {
        $bot_response = "Lo siento, no entiendo tu mensaje.";
    }

    echo json_encode(['response' => $bot_response]);
}

$conn->close();
?>
