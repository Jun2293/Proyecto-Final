<?php


//constante 
date_default_timezone_set("America/Guatemala");
const SERVERURL="http://localhost/SistemaRequerimiento/";
//const SERVERURL="https://url.com/";



?>