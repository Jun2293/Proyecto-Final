
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="<?php echo SERVERURL; ?>app/js/sweetalert.min.js"></script>
      <script type="text/javascript" src="<?php echo SERVERURL; ?>app/js/push.min.js"></script>
      <script type="text/javascript" src="<?php echo SERVERURL; ?>app/js/masonry.min.js"></script>
      <script type="text/javascript" src="<?php echo SERVERURL; ?>app/js/materialize.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	    <script type="text/javascript" src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript">

            $('.modal').modal({
                  startingTop: '10%',
            });
            
            $('.collapsible').collapsible();

      	function actResponsive(){
       	var $masonry = $('#mansoryDiv');
			$masonry.masonry({
			  // set itemSelector so .grid-sizer is not used in layout
			  ///itemSelector: '.row',
			  // use element for option
			  columnWidth: '.col',
			  // no transitions
			  transitionDuration: 0,
			  horizontalOrder: true,
			});
      	}

      </script>



	  <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recaptchaSecret = 'TU_CLAVE_SECRETA';
    $recaptchaResponse = $_POST['recaptchaResponse'];

    // Verificar el token con Google
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = [
        'secret' => $recaptchaSecret,
        'response' => $recaptchaResponse,
    ];

    // Hacer la solicitud POST
    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    $response = json_decode($result);

    // Verificar la respuesta
    if ($response->success && $response->score >= 0.5) {
        // El token es válido y el usuario es humano
        echo "Verificación exitosa. ¡Bienvenido!";
    } else {
        // El token es inválido o el usuario es sospechoso
        echo "Verificación fallida. Intenta nuevamente.";
    }
}


?>
