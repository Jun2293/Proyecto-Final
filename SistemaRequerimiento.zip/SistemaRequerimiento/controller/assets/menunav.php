<!--Menu Admin-->
<!-- Dropdown Structure -->
<ul id="menuadmin" class="dropdown-content">
  <li><a href="./settings.php" class="black-text"><i class="material-icons black-text">build</i>Configuración</a></li>
  <li class="divider"></li>
  <li><a href="../controller/assets/salir.php" class="black-text"><i class="material-icons black-text">exit_to_app</i>Salir</a></li>
</ul>
<!--Menu Admin-->
<!-- Dropdown Structure -->

<a id="nivelUser" class="hide"><?php echo $template_tipo ?></a>

<!-- NAV -->
<ul id="slide-out" class="sidenav sidenav-fixed">
  <li style="height: auto;">
    <div class="user-view" style="width: 100%;">
      <div class="row center">
        <div class="col s12">
          <img width="80%" src="../docs/iconos/muni.png">
        </div>
      </div>
    </div>
  </li>
  <li>
    <div class="user-view" style="padding: 0px 32px 0;">
      <a><span class="black-text email"><strong><?php echo $template_email; ?></strong></span></a>
    </div>
  </li>
  <li><a class="subheader">Menú</a></li>

  <li><a id="n1" href="./"><i id="i1" class="material-icons">web</i>Menú</a></li>
  <li><a id="n2" class="truncate" href=""><i id="i2" class="material-icons">view_comfy</i>Datos</a></li>

  <!-- Opciones del menú -->
  <li>
    <a id="n9" href="./usuario.php">
      <i id="i9" class="material-icons">face</i>Usuario
    </a>
  </li>
  <li><a id="n4" href="../controller/assets/salir.php"><i id="i5" class="material-icons">exit_to_app</i>Salir</a></li>
</ul>

<!-- Estructura de Chatbot -->
<div>
    <!-- Element Showed -->
    <a id="menu" class="waves-effect waves-light btn btn-floating" onmouseover="showQuestions()" onmouseout="hideQuestions()">
        <i class="material-icons">menu</i>
    </a>

    <!-- Menú de preguntas -->
    <div id="questionMenu" style="display: none; position: absolute; background: white; border: 1px solid #ccc; padding: 10px; z-index: 1000;">
        <button onclick="askQuestion('¿Cuál es tu nombre?')">¿Como podemos ayudarte?</button><br>
        <button onclick="askQuestion('¿Qué servicios ofreces?')">¿Cuentanos tu experiencia?</button><br>
        <button onclick="askQuestion('¿Cómo puedo contactarte?')">¿Contactanos?</button>
    </div>

    <!-- Tap Target Structure -->
    <div id="chatbot" class="tap-target" style="display: none;">
      <div class="tap-target-content">
        <h5>Chatbot</h5>
        <h2>Registro de Solicitud</h2>
        <div id="chat" style="width: 300px; height: 250px; border: 1px solid #ccc; overflow-y: scroll; padding: 10px;"></div>
        <input type="text" id="userInput" placeholder="¿Cómo puedo ayudarte?">
        <button onclick="sendMessage()">Enviar</button>
      </div>
    </div>
</div>
<!-- Estructura de Chatbot -->

<!-- NAV -->
<script type="text/javascript" charset="utf-8" async>
  let tipoUserV = $("#nivelUser").text();
  console.info("Admin", tipoUserV);

  function toggleChat() {
    const chatbot = document.getElementById('chatbot');
    chatbot.style.display = chatbot.style.display === 'none' ? 'block' : 'none';
  }

  function showQuestions() {
    const questionMenu = document.getElementById('questionMenu');
    questionMenu.style.display = 'block';
  }

  function hideQuestions() {
    const questionMenu = document.getElementById('questionMenu');
    questionMenu.style.display = 'none';
  }

  function sendMessage() {
    const input = document.getElementById('userInput');
    const chat = document.getElementById('chat');

    // Agregar el mensaje del usuario al chat
    const userMessage = document.createElement('div');
    userMessage.textContent = 'Usuario: ' + input.value;
    chat.appendChild(userMessage);

    // Limpiar el campo de entrada
    input.value = '';

    // Respuesta del chatbot
    const botResponse = document.createElement('div');
    botResponse.textContent = 'Chatbot: ¿Cómo te puedo ayudar hoy?';
    chat.appendChild(botResponse);

    // Desplazar el scroll hacia abajo
    chat.scrollTop = chat.scrollHeight;
  }

  function askQuestion(question) {
    const chat = document.getElementById('chat');

    // Agregar la pregunta al chat
    const userMessage = document.createElement('div');
    userMessage.textContent = 'Usuario: ' + question;
    chat.appendChild(userMessage);

    // Respuesta del chatbot
    const botResponse = document.createElement('div');
    botResponse.textContent = 'Chatbot: Gracias por tu pregunta. Aquí está la información que necesitas.';
    chat.appendChild(botResponse);

    // Desplazar el scroll hacia abajo
    chat.scrollTop = chat.scrollHeight;
  }
</script>

<!-- NAV PRINCIPAL-->
<nav class="colorP borde7 hoverable" style="width: 97% !important; margin-left: 1.5%; margin-top: 1%; margin-bottom: 25px;">
  <div class="nav-wrapper" style="margin: 25px;">
    <a class="brand-logo" href="#"><i id="ocultarnav" class="material-icons hide-on-med-and-down">fullscreen</i>Registro de Solicitud</a>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
    <ul class="right hide-on-med-and-down">
      <li><a class="busquedaglobal"><i class="material-icons left">search</i></a></li>
      <li><a id="zonaBienvenido" class="truncate">Hola </a></li>
      <li><a id="dropdownuser" class="dropdown-trigger" data-target="menuadmin"><i class="material-icons left white-text">face</i><?php echo $template_nombre; ?><i class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
  </div>
  <!-- Formulario para registrar solicitudes -->
  <div id="solicitudForm" style="margin-top: 20px;">
      <h5>Registrar Solicitud</h5>
      <form action="procesar_solicitud.php" method="POST" enctype="multipart/form-data">
          <div>
              <label for="nombre">Oficio:</label>
              <input type="text" id="nombre" name="nombre" required>
          </div>
          <div>
              <label for="descripcion">Descripción de la solcitud:</label>
              <textarea id="descripcion" name="descripcion" required></textarea>
          </div>
          <div>
              <label for="archivo">Subir archivo (PDF):</label>
              <input type="file" id="archivo" name="archivo" accept=".pdf" required>
          </div>
          <button type="submit">Enviar Solicitud</button>
      </form>
  </div>
</nav>
<!-- NAV PRINCIPAL-->

<script type="text/javascript" charset="utf-8">
  $("#zonaBienvenido").text("");

  var menunavID = <?php echo $nav ?>;
  if (menunavID == "0") {
    $("#n" + menunavID + "").addClass('animated fadeOut');
    setTimeout(function() {
      $("#n" + menunavID + "").addClass('hide');
    }, 500);
  } else {
    $("#n" + menunavID + "").addClass('fontP');
    $("#i" + menunavID + "").addClass('accentfP');
  }

  $("#ocultarnav").click(function(event) {
    event.preventDefault();
    if ($("#slide-out").hasClass('sidenav-fixed')) {
      $("#ocultarnav").text('fullscreen');
      $("#slide-out").removeClass('sidenav-fixed');
      $("#bodyprin").removeClass('responsivo');
      $('.sidenav').sidenav("close");
      actResponsive();
    } else {
      $("#slide-out").addClass('sidenav-fixed');
      $("#bodyprin").addClass('responsivo');
      $('.sidenav').sidenav("open");
    }
  });
</script>