<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_code = $_POST['code'];
    if ($input_code == $_SESSION['verification_code']) {
        echo "¡Bienvenido, " . $_SESSION['username'] . "!";
        // Aquí puedes redirigir al usuario a su panel de control
        // header('Location: dashboard.php');
    } else {
        echo "Código de verificación incorrecto.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificación en Dos Pasos</title>
</head>
<body>
    <h2>Verificación en Dos Pasos</h2>
    <form action="" method="POST">
        <input type="text" name="code" placeholder="Código de verificación" required>
        <button type="submit">Verificar</button>
    </form>
</body>
</html>
