<?php
$modulo = "Login";

require_once "controller/assets/validacion.php";

//Validacion de login
$login = new seguridad;
$login->iniciologin();

require_once "controller/assets/svrurl.php";
require_once "controller/assets/inicio.php";

//Numeros aleatrrios
$num1=rand(1,10);
$num2=rand(1,10);

?>
<div class="row animated fadeIn" style="margin-bottom: 20;"><!-- row principal-->

  <!-- CARD BLANCO -->

  <div class="row center" style="margin-top: 25vh;">
    <div class="col s12">
      <img width="20%" src="../docs/iconos/muni.png">
      <h4 style="color: black;">Sistema de Requerimieto</h4>
      <h5 style="color: black;">Ingrese los siguientes datos:</h5>S
    </div>
    <div class="col s8 offset-s4">
      <form id="login" accept-charset="utf-8" action="">
        <div class="row">
          <div class="col s12 m12">
            <div class="left">
              <span class="black-text" style="font-size: 18px;">Correo</span>
            </div>
          </div>
          <div class="col s12 m8">
            <div class="input-field col s11 m8">
              <input type="email" name="email" id="email" class="validate black-text login-input" required>
            </div>
          </div>
          <div class="col s12 m12">
            <div class="left">
              <span class="black-text" style="font-size: 18px;">Contraseña</span>
            </div>
          </div>
          <div class="col s12 m8">
            <div class="input-field col s11 m8">
            <input type="password" name="contra" id="pass" required class="validate black-text login-input" pattern="^.{8,25}" title="La contraseña debe tener al menos 8 caracteres, incluyendo letras y números. No se permiten caracteres especiales no estándar.">
            </div>
          </div>

        <!-- Verificador humano -->
        <div class="col s12 m12">
          <div class="left">
            <span class="black-text" style="font-size: 18px;">¿Cuánto es <?php echo $num1; ?> + <?php echo $num2; ?></span>
          </div>
        </div>
        <div class="col s12 m8">
          <div class="input-field col s11 m8">
            <input type="number" name="human_check" id="human_check" class="validate black-text login-input" required>
          </div>
          <div>
          <script src="https://www.google.com/recaptcha/enterprise.js?render=6LdO3HIqAAAAAGnYuNCdcIiemlJCoP0nuImnvcUn"></script>
          <!-- recap -->
          </div>
        </div>
         <!-- Verificador humano -->
        </div>
        <div class="row">
          <div class="col s12 m12">
            <div class="col s4 offset-s4 m5">
              <div class="left">
                <input type="submit" id="botonlogin" class=" colorP btn-large  white-text" value="Ingreso" style="font-size: 18px; border-radius: 7px;">
                <input type= "hidden" id="sum_result" value="<?php echo $num1 + $num2; ?>">
                <form action="scripts.php" method="POST">
                <!-- Otros campos del formulario -->
                <input type="hidden" name="recaptchaResponse" id="recaptchaResponse">
                </form>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>


  <!-- Derechos reservados -->
  <div class="row center">
    <div class="col s12" style="position: fixed; bottom: 0;">
      <span class="black-text" style="font-size: 20px;">MuniMixco<a class="black-text" href=""></a></span>
    </div>
  </div>
  <!-- Derechos reservados -->

</div><!-- row principal-->
<!-- row principal-->
<!-- SCRIPTS CARGA -->
<?php
require_once "controller/assets/scripts.php";
?>
<!-- SCRIPTS CARGA -->
<script>
jQuery(document).on("submit", "#login", function (event) {
  event.preventDefault();

  // Verificar si el usuario respondió correctamente a la pregunta
  const humanCheck = parseInt(jQuery("#human_check").val());
  const sum_Check = parseInt(jQuery("#sum_result").val());
  if (humanCheck !== sum_Check) {
    swal("Oops", "Respuesta incorrecta a la pregunta de verificación!", "error");
    return;
  }

  jQuery("#botonlogin").addClass("disabled");

  jQuery.ajax({
    url: "controller/db/login.php",
    type: "POST",
    dataType: "json",
    data: jQuery("#login").serialize(),
    cache: "false",
    beforeSend: function () {
      M.toast({
        html: "Cargando...",
        classes: "rounded colorP",
        timeRemaining: 50,
      });
    },
  })
    .done(function (data) {
      if (data.acceso == "si") {
        console.log(data);
        window.location.href = "view/index.php";

        //swal ( "PM SCRUM" ,  "Bievenido al sistema" ,  "success" );
        jQuery("#botonlogin").removeClass("disabled");
      } else if (data.acceso == "no") {
        //Usuario Invalido
        swal("Sistema", "Usuario Bloqueado Informar a Desarollo", "info");
        jQuery("#botonlogin").removeClass("disabled");
      } else if (data.error == true) {
        swal("Oops", "Correo o contraseña incorrecta! ", "info");
        jQuery("#botonlogin").removeClass("disabled");
      }
    })
    .fail(function (errordata) {
      console.log(errordata.responseText);
    });
});
//validacion de script de recaptcha

recaptcha.ready(function() {
            document.getElementById('yourForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Evita el envío inmediato
                grecaptcha.execute('6LdO3HIqAAAAAGnYuNCdcIiemlJCoP0nuImnvcUn', {action: 'USER_ACTION'}).then(function(token) {
                    document.getElementById('recaptchaResponse').value = token;
                    document.getElementById('yourForm').submit(); // Envía el formulario
                });
            });
        });
        function sendMessage() {
            const message = document.getElementById('userInput').value;
            document.getElementById('chat').innerHTML += `<div>Tú: ${message}</div>`;
            document.getElementById('userInput').value = '';

            fetch('chatbot.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `message=${encodeURIComponent(message)}`
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('chat').innerHTML += `<div>Bot: ${data.response}</div>`;
                document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight;
            });
        }
</script>

<!-- Fin HTML -->
<?php
require_once "controller/assets/fin.php";
?>